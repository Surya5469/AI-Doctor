import speech_recognition as sr
import pyttsx3
import pandas as pd
import time
import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
from PIL import Image, ImageTk  
import json
import os

engine = pyttsx3.init()
engine.setProperty('rate', 150)
engine.setProperty('volume', 1)

def speak(text):
    print(text)  
    engine.say(text)
    engine.runAndWait()

def get_voice_input(prompt):
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        speak(prompt)
        recognizer.adjust_for_ambient_noise(source, duration=1)  # Shorter ambient noise adjustment
        recognizer.energy_threshold = 300  # Lower the threshold for sensitivity
        try:
            audio = recognizer.listen(source, timeout=5, phrase_time_limit=3)  # Extended listening time
            print("Recognizing...")
            response = recognizer.recognize_google(audio).lower()
            time.sleep(2)  # Pause to allow the user to answer fully
            return response
        except sr.UnknownValueError:
            speak("Sorry, I couldn't understand that. Proceeding without response.")
            return ""
        except sr.RequestError:
            speak("There was an issue with the speech recognition service.")
            return ""

def load_disease_data_from_excel(file_path):
    df = pd.read_excel(file_path)
    diseases = []
    for _, row in df.iterrows():
        disease = {
            "name": row['Disease'],
            "symptoms": row['Symptoms'].split(", "),
            "recommendation": row['Recommendation'],
            "prescription": row['Prescription']
        }
        diseases.append(disease)
    return diseases

# Function to match symptoms with diseases
def match_disease(symptoms_input, diseases):
    matched_diseases = []
    input_symptoms = set(symptoms_input.split(", "))  # Convert to set for comparison

    for disease in diseases:
        disease_symptoms = set(disease['symptoms'])
        common_symptoms = input_symptoms.intersection(disease_symptoms)

        if common_symptoms:
            matched_diseases.append({
                "name": disease["name"],
                "matched_symptoms": common_symptoms,
                "all_symptoms": disease['symptoms'],
                "recommendation": disease["recommendation"],
                "prescription": disease["prescription"]
            })

    return matched_diseases

# Function to ask for unique symptoms across matched diseases
def ask_for_unique_symptoms(matched_diseases):
    all_symptoms = []
    for disease in matched_diseases:
        all_symptoms.extend(disease['all_symptoms'])

    symptom_counts = {symptom: all_symptoms.count(symptom) for symptom in all_symptoms}
    unique_symptoms = [symptom for symptom, count in symptom_counts.items() if count == 1]

    if unique_symptoms:
        speak("Please confirm the following unique symptoms:")
        speak(", ".join(unique_symptoms))
        response = get_voice_input("Please confirm the symptoms one by one.")

        for disease in matched_diseases:
            disease["matched_symptoms"].update(set(unique_symptoms).intersection(response.split(", ")))

    return matched_diseases

# Function to save user data (diagnosis history)
def save_user_data(username, diagnosis_data):
    file_path = f"{username}_data.json"
    if os.path.exists(file_path):
        with open(file_path, 'r') as file:
            user_data = json.load(file)
    else:
        user_data = {}

    if 'diagnosis_history' not in user_data:
        user_data['diagnosis_history'] = []
    
    user_data['diagnosis_history'].append(diagnosis_data)
    
    with open(file_path, 'w') as file:
        json.dump(user_data, file)

# Function to load user data (diagnosis history)
def load_user_data(username):
    file_path = f"{username}_data.json"
    if os.path.exists(file_path):
        with open(file_path, 'r') as file:
            user_data = json.load(file)
        return user_data
    else:
        return {"diagnosis_history": []}

# Function to handle the diagnosis process
def start_diagnosis(username):
    file_path = r"C:\Users\vishu\OneDrive\Desktop\ai doc\disease_data.xlsx"  # Update with your actual path
    diseases = load_disease_data_from_excel(file_path)

    symptoms_input = get_voice_input("Please say your symptoms:")

    if symptoms_input:
        matched_diseases = match_disease(symptoms_input, diseases)

        if matched_diseases:
            matched_diseases = ask_for_unique_symptoms(matched_diseases)
            matched_diseases.sort(key=lambda x: len(x['matched_symptoms']), reverse=True)

            top_disease = matched_diseases[0]

            result = f"Most Likely Disease: {top_disease['name']}\n"
            result += f"Matched Symptoms: {', '.join(top_disease['matched_symptoms'])}\n"
            result += f"Recommendation: {top_disease['recommendation']}\n"
            result += f"Prescription: {top_disease['prescription']}\n"

            result_label.config(text=result)
            speak(f"The most likely disease based on your symptoms is {top_disease['name']}.")

            diagnosis_data = {"disease": top_disease['name'], "prescription": top_disease['prescription'], "symptoms": symptoms_input}
            save_user_data(username, diagnosis_data)
        else:
            result_label.config(text="No matching disease found. Please try again.")
            speak("No matching disease found. Please check the symptoms and try again.")
    else:
        result_label.config(text="No symptoms detected. Please try again.")
        speak("Sorry, I couldn't detect any symptoms. Please try again.")

# Function to display previous diagnosis history
def display_history(username):
    user_data = load_user_data(username)
    history = user_data['diagnosis_history']
    if history:
        history_list = [f"{i+1}. {entry['disease']} - {entry['prescription']}" for i, entry in enumerate(history)]
        history_dropdown['values'] = history_list
        history_dropdown.set('Select a Previous Diagnosis')
    else:
        history_dropdown['values'] = ['No history found']

# GUI setup
def create_gui():
    global result_label, history_dropdown

    window = tk.Tk()
    window.title("AI Doctor")
    window.geometry("500x600")  # Set size of the window
    window.config(bg="#f0f0f0")

    # Load background image
    bg_image = Image.open(r"C:/Users/vishu/OneDrive/Desktop/ai doc/ai-dr.jpeg")  # Correct path format
    bg_image = bg_image.resize((500, 600), Image.LANCZOS)  # Resize to fit window size
    bg_photo = ImageTk.PhotoImage(bg_image)

    # Add background image to window
    background_label = tk.Label(window, image=bg_photo)
    background_label.place(relwidth=1, relheight=1)

    # Title Label
    title_label = tk.Label(window, text="AI Doctor", font=("Arial", 24, "bold"), bg="#f0f0f0", fg="#333")
    title_label.pack(pady=20)

    # Login Section
    username_label = tk.Label(window, text="Username:", font=("Arial", 12), bg="#f0f0f0", fg="#333")
    username_label.pack(pady=5)

    username_entry = tk.Entry(window, font=("Arial", 12))
    username_entry.pack(pady=5)

    password_label = tk.Label(window, text="Password:", font=("Arial", 12), bg="#f0f0f0", fg="#333")
    password_label.pack(pady=5)

    password_entry = tk.Entry(window, show="*", font=("Arial", 12))
    password_entry.pack(pady=5)

    # Login Button
    def login():
        username = username_entry.get()
        password = password_entry.get()

        if username and password:
            create_diagnosis_screen(username)  # Proceed to diagnosis screen if login is successful
        else:
            messagebox.showerror("Error", "Please enter both username and password.")

    login_button = tk.Button(window, text="Login", font=("Arial", 14), command=login, bg="#4CAF50", fg="white", padx=20, pady=10)
    login_button.pack(pady=30)

    window.mainloop()

# Diagnosis Screen setup with history dropdown
def create_diagnosis_screen(username):
    global result_label, history_dropdown

    window = tk.Tk()
    window.title(f"AI Doctor - {username}")
    window.geometry("500x600")
    window.config(bg="#f0f0f0")

    # Title Label
    title_label = tk.Label(window, text="AI Doctor Diagnosis", font=("Arial", 24, "bold"), bg="#f0f0f0", fg="#333")
    title_label.pack(pady=20)

    # Dropdown to view history
    history_label = tk.Label(window, text="View Previous Diagnosis:", font=("Arial", 12), bg="#f0f0f0", fg="#333")
    history_label.pack(pady=10)

    history_dropdown = ttk.Combobox(window, width=40, font=("Arial", 12))
    history_dropdown.pack(pady=10)

    # Show history when the dropdown is updated
    display_history(username)

    # Diagnosis Result Section
    result_label = tk.Label(window, text="", font=("Arial", 14), justify=tk.LEFT, bg="#f0f0f0", fg="#333")
    result_label.pack(pady=10)

    # Button to start new diagnosis
    start_button = tk.Button(window, text="Start Diagnosis", font=("Arial", 16), command=lambda: start_diagnosis(username), bg="#4CAF50", fg="white", padx=20, pady=10)
    start_button.pack(pady=30)

    window.mainloop()

# Run the app
create_gui()