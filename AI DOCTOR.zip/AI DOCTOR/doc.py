import speech_recognition as sr
import pyttsx3
import pandas as pd
import time

# Initialize pyttsx3 engine
engine = pyttsx3.init()

# Set properties for speech (Optional: adjust rate and volume)
engine.setProperty('rate', 150)  # Speed of speech (default is 200)
engine.setProperty('volume', 1)  # Volume (0.0 to 1.0)

# Function to speak out text
def speak(text):
    print(text)  # Print text for reference
    engine.say(text)
    engine.runAndWait()

# Backup method to allow typing if speech recognition fails
def get_backup_input(prompt):
    speak(f"Could you please type your symptoms? {prompt}")
    symptoms_input = input("Type your symptoms (separate with commas): ")
    return symptoms_input.lower()

# Function to capture voice input with a prompt and improved listening settings
def get_voice_input(prompt):
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        speak(prompt)
        recognizer.adjust_for_ambient_noise(source, duration=1)  # Shorter ambient noise adjustment
        recognizer.energy_threshold = 300  # Lower the threshold for sensitivity
        try:
            audio = recognizer.listen(source, timeout=15, phrase_time_limit=15)  # Extended listening time
            print("Recognizing...")
            response = recognizer.recognize_google(audio).lower()
            print(f"Recognized: {response}")  # Debugging line
            time.sleep(2)  # Pause to allow the user to answer fully
            return response
        except sr.UnknownValueError:
            speak("Sorry, I couldn't understand that. Let's try typing the symptoms instead.")
            return get_backup_input(prompt)  # Allow user to type if voice input fails
        except sr.RequestError:
            speak("There was an issue with the speech recognition service.")
            return get_backup_input(prompt)  # Allow user to type if service fails

# Function to properly parse and split the symptoms from input
def parse_symptoms(input_str):
    # Replace common conjunctions like 'and' with commas
    input_str = input_str.replace("and", ",")
    # Split by comma and strip extra spaces
    symptoms = [symptom.strip() for symptom in input_str.split(",")]
    return symptoms

# Load disease data from an Excel file
def load_disease_data_from_excel(file_path):
    df = pd.read_excel(file_path)
    diseases = []
    for _, row in df.iterrows():
        disease = {
            "name": row['Disease'],
            "symptoms": row['Symptoms'].split(", "),
            "recommendation": row['Recommendation'],
            "prescription": row['Prescription']
        }
        diseases.append(disease)
    return diseases

# Function to match symptoms with diseases
def match_disease(symptoms_input, diseases):
    matched_diseases = []
    input_symptoms = set(symptoms_input)  # Convert to set for comparison
    print(f"Input Symptoms: {input_symptoms}")  # Debugging line

    for disease in diseases:
        disease_symptoms = set(disease['symptoms'])
        common_symptoms = input_symptoms.intersection(disease_symptoms)

        print(f"Matching {disease['name']}: Common Symptoms = {common_symptoms}")  # Debugging line

        if common_symptoms:
            matched_diseases.append({
                "name": disease["name"],
                "matched_symptoms": common_symptoms,
                "all_symptoms": disease['symptoms'],
                "recommendation": disease["recommendation"],
                "prescription": disease["prescription"]
            })

    return matched_diseases

# Function to ask for unique symptoms across matched diseases
def ask_for_unique_symptoms(matched_diseases):
    # Collect all symptoms from the matched diseases
    all_symptoms = []
    for disease in matched_diseases:
        all_symptoms.extend(disease['all_symptoms'])

    # Find unique symptoms (those that are not shared across diseases)
    symptom_counts = {symptom: all_symptoms.count(symptom) for symptom in all_symptoms}
    unique_symptoms = [symptom for symptom, count in symptom_counts.items() if count == 1]

    # Speak the unique symptoms immediately, in the background
    if unique_symptoms:
        speak("Please note the following unique symptoms:")
        speak(", ".join(unique_symptoms))  # This will speak all unique symptoms at once

    # Now we proceed with telling the symptoms in the second round
    speak("Now, let me tell you the unique symptoms. Please listen carefully.")
    return unique_symptoms

# Main function
def main():
    file_path = r"C:\Users\vishu\OneDrive\Desktop\ai doc\disease_data.xlsx"  # Old file path
    diseases = load_disease_data_from_excel(file_path)

    # First ask for the initial set of symptoms
    speak("Please say your symptoms, separated by commas (e.g., sneezing, fever):")
    symptoms_input = get_voice_input("Please say your symptoms:")

    if not symptoms_input:
        speak("No symptoms detected. Please try again.")
        return  # Exit or prompt the user again

    # Parse and process symptoms
    symptoms_input_list = parse_symptoms(symptoms_input)
    speak(f"You said: {', '.join(symptoms_input_list)}")
    
    matched_diseases = match_disease(symptoms_input_list, diseases)

    if matched_diseases:
        # Narrow down the diseases by asking for more unique symptoms
        unique_symptoms = ask_for_unique_symptoms(matched_diseases)

        # Proceed to the second round of symptoms discussion
        speak("Here are the unique symptoms you may have: ")
        speak(", ".join(unique_symptoms))

        # Now you will speak the symptoms you have from the list
        speak("Please tell me which of the unique symptoms you have. Say them using 'and'.")
        second_round_input = get_voice_input("Please tell me which unique symptoms you have.")

        # Parse and process second round input
        second_round_symptoms = parse_symptoms(second_round_input)
        speak(f"You said: {', '.join(second_round_symptoms)}")

        # Match the second-round symptoms with diseases again
        matched_diseases = match_disease(second_round_symptoms, diseases)

        # Sort by the most relevant result (based on matching symptoms count)
        matched_diseases.sort(key=lambda x: len(x['matched_symptoms']), reverse=True)

        # Select only the top result (the most relevant disease)
        top_disease = matched_diseases[0]

        # Provide the final diagnosis based on the matched symptoms
        speak(f"The most likely disease based on your symptoms is {top_disease['name']}.")
        speak(f"Recommendation: {top_disease['recommendation']}")
        speak(f"Prescription: {top_disease['prescription']}")
    else:
        speak("No matching disease found. Please check the symptoms and try again.")

if __name__ == "__main__":
    main()
